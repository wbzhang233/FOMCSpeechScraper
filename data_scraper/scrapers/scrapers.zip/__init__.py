# from scrapers.altanta import AtlantaSpeechScraper
# from board import BOGSpeechScraper
# from boston import BostonSpeechScraper
# from chicago import ChicagoSpeechScraper
# from cleveland import ClevelandSpeechScraper
# from dallas import DallasSpeechScraper
# from kansas_city import KansasCitySpeechScraper
# from minneapolis import MinneapolisSpeechScraper
# from new_york import NewYorkSpeechScraper
# from philadelphia import PhiladelphiaSpeechScraper
# from richmond import RichmondSpeechScraper
# from san_francisco import SanFranciscoSpeechScraper
# from stlouis import StLouisSpeechScraper

# from freser_scraper import FRESERScraper

